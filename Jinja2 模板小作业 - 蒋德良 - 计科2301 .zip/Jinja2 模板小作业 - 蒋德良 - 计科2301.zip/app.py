# 项目名称：Flask Jinja2模板技术小作业
# 班级：计科2301
# 学号：20230502015
# 姓名：蒋德良

from flask import Flask, render_template, url_for
import time

app = Flask(__name__)


# ========== 作业1：基础模板使用与变量注入 ==========
@app.route('/value')
@app.route('/value/<username>')
def value(username=None):
    """作业1：变量注入演示，无参数时username默认为None，模板中显示'游客'"""
    return render_template('value.html', username=username)


# ========== 作业2：URL生成与控制结构使用 ==========
@app.route('/article')
@app.route('/article/<int:num>')
def article(num=0):
    """作业2：文章列表演示，生成num条模拟文章数据，支持空数据判断"""
    articles = []
    if num > 0:
        for i in range(1, num + 1):
            articles.append({
                'title': f'文章{i}标题',
                'content': f'文章{i}内容'
            })
    return render_template('article.html', num=num, articles=articles)


# ========== 作业3：模板的包含与继承 ==========
@app.route('/extend')
def extend_page():
    """作业3：模板继承与包含演示，直接渲染extend.html，无需变量注入"""
    return render_template('extend.html')


# ========== 作业4：宏指令的定义与调用 ==========
@app.route('/macro')
@app.route('/macro/<int:num>')
def macro_page(num=0):
    """作业4：宏指令演示，生成num条文章数据，计算上一页/下一页编号"""
    articles = []
    if num > 0:
        for i in range(1, num + 1):
            articles.append({
                'title': f'文章{i}标题',
                'content': f'文章{i}内容'
            })
    return render_template('macro.html', num=num, articles=articles,
                           num_prev=num - 1, num_next=num + 1)


# ========== 作业5：变量过滤器（内置+自定义） ==========
def format_title(title):
    """自定义过滤器：文章标题首字母大写，其余字母小写"""
    return title.capitalize()


# 注册自定义过滤器
app.add_template_filter(format_title, 'format_title')


@app.route('/filter')
@app.route('/filter/<int:num>')
def filter_page(num=0):
    """作业5：过滤器演示，生成含时间戳的文章列表"""
    articles = []
    if num > 0:
        for i in range(1, num + 1):
            articles.append({
                'title': f'ARTICLE {i} TITLE',
                'content': f'这是文章{i}的详细内容，用于测试截断过滤器效果，这段文字足够长以触发截断。',
                'create_time': time.time()
            })
    return render_template('filter.html', num=num, articles=articles)


# ========== 自定义404错误页面 ==========
@app.errorhandler(404)
def page_not_found(e):
    """自定义404页面，显示友好提示"""
    return render_template('404.html'), 404


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
